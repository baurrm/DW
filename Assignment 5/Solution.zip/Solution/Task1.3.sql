SELECT * 
FROM Production.Product
WHERE ProductLine is NULL