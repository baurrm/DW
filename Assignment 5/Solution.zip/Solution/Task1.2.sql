SELECT *
FROM Production.Product
WHERE ProducSize is NULL