SELECT *
INTO SalesLocationDIM
FROM dbo.SalesTerritory AS a;
GO