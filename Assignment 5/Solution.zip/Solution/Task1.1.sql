SELECT *
FROM Production.Product
WHERE ProducColor is NULL