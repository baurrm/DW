/****** Script for SelectTopNRows command from SSMS  ******/
SELECT [SalesTerritoryName]
      ,[SalesTerritoryGroup]
  FROM [AWStageDB].[Sales].[SalesTerritory]